"""Validation for the single fixed partial-reference fitting diagnostic."""
import hashlib
import json


def validate_card(card):
    from .governance import ValidationReport
    errors=[]
    try:
        s=card['scope'];a=card['approval'];b=s['binding']
        assert card['schema_version']=='gse_membership_fit_card_v1'
        assert a['status']=='APPROVED' and a['authorized_operations']==['training'] and a['authorized_gates']==[3]
        assert a['scope_sha256']==hashlib.sha256(json.dumps(s,sort_keys=True).encode()).hexdigest()
        assert s['updates']==500 and s['seed']==0 and s['variant']=='C'
        assert s['learning_rate']==.001 and s['weight_decay']==.0001 and s['accumulation']==4
        assert b['selected_windows']==16 and b['selected_unique_frames']==80
        assert b['decoded_observations_per_uncached_pass']==105 and len(b['entries'])==16
        assert len({e['source']['parent_id'] for e in b['entries']})==8
        assert all(e['source']['split']=='fit' and e['source']['parent_id'].rsplit('_',1)[1] in
                   {'C01','C02','C03','C04','C05','C06'} for e in b['entries'])
        assert s['unknown_is_background'] is False and s['teacher_in_forward'] is False
        assert s['limits']==dict(wall_seconds=7200,host_bytes=32*1024**3,gpu_bytes=28*1024**3,output_bytes=4*1024**3)
    except (KeyError,TypeError,AssertionError,IndexError):errors.append('fixed partial-reference fitting contract drift')
    return ValidationReport(passed=not errors,errors=errors,warnings=[])
