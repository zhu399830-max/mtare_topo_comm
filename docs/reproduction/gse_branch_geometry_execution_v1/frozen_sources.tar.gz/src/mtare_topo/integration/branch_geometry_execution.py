"""Local geometry-place task selection over the existing execution handoff.

This first wiring selects CURRENTLY OBSERVED tasks only. Stored remote tasks
remain explicit, not silently claimed reached or sent as straight-line goals.
Remote return requires the recorded-route planner and is not implemented here.
"""
from copy import deepcopy
import numpy as np
from mtare_topo.integration.geometry_execution import GeometryExecution
from mtare_topo.topology.geometry_branch_places import GeometryBranchPlaces


class BranchGeometryExecution:
    def __init__(self, *, execution_policy, place_policy):
        self.execution=GeometryExecution(**execution_policy)
        self.places=GeometryBranchPlaces(**place_policy)
        self.events=self.execution.events
        self.decisions=[]

    def update_geometry(self,result,*,body_xyz_m,body_forward_world,stamp_sec):
        g=result['geometry'];proposals=result['decision']['proposals']
        observation=self.places.observe(g,proposals,navigation_node_id=result['decision']['node'])
        selected=None
        if observation.get('status')=='supported_observation':
            place=self.places.places[observation['place_id']]
            candidates=[f for f in place['frontiers'] if f['state']=='unattempted' and f['last_order']==g['timestamp']]
            # At a decision place, prioritize a lateral alternative over
            # straight/back continuations. This is a fixed engineering policy,
            # not a learned planner or a claim that the branch is traversable.
            if candidates:
                selected=min(candidates,key=lambda f:(abs(float(np.asarray(f['direction_world'])@np.asarray(body_forward_world))),f['id']))
                proposals=[dict(axis_target_xyz_m=list(selected['target_xyz_m']),
                    source_refs=list(selected['source_refs']),
                    branch_task=dict(place_id=place['id'],frontier_id=selected['id']))]
        before=len(self.events)
        request=self.execution.update(proposals,body_xyz_m=body_xyz_m,
            body_forward_world=body_forward_world,stamp_sec=stamp_sec)
        for event in self.events[before:]:
            identity=event['target'].get('branch_task')
            if identity is None:continue
            outcome={'TENTATIVE_GOAL_REQUEST':'requested','XY_ARRIVAL_FROM_ODOMETRY':'xy_arrived','TARGET_TIMEOUT':'blocked'}[event['kind']]
            self.places.record_attempt(**identity,outcome=outcome,stamp_sec=stamp_sec)
        pending=sum(f['state']=='unattempted' for p in self.places.places if p['state']=='supported_observation' for f in p['frontiers'])
        self.decisions.append(dict(stamp_sec=stamp_sec,observation=observation,
            request_status=request['status'],task=request.get('active',{}).get('branch_task') if request.get('active') else None,
            pending_tasks=pending))
        return request

    def snapshot(self):
        return dict(places=self.places.snapshot(),decisions=deepcopy(self.decisions),
                    remote_return_implemented=False)
